<?php global $teba_options; ?>
<a href="#" id="back-to-top" class="progress hide_icon"><div class="arrow-top"></div>
   <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="xMinYMin meet"><path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"/></svg>
</a>
<footer class="footer_v0"></footer>
