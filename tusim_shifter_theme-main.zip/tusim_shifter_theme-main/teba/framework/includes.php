<?php
/* Metaboxes */
/* Load Shortcodes Function */
require_once TEBA_ABS_PATH_FR . '/shortcodes/shortcode-functions.php';
/* Load Shortcodes */
require_once TEBA_ABS_PATH_FR . '/shortcodes/shortcodes.php';
/* Load Mega menu admin */
require_once TEBA_ABS_PATH_FR . '/megamenu/mega-menu.php';
