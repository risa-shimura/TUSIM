=== Teba ===
Contributors: motivoweb
Requires at least: WordPress 5.5
Tested up to: WordPress 5.5.1
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, two-columns, right-sidebar, custom-background, custom-header, custom-menu, featured-images, post-formats, sticky-post, theme-options, translation-ready


== Description ==
Teba is IT Solutions & Services WordPress Theme for agency that will showcase your for Freelancers, business, Portfolio, app or blogging (plus much more).


== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Upload your theme files teba.zip
3. Click on the 'Activate' button to use your new theme right away.
4. Go to theme documentation for detailed instructions.

== Copyright ==

You must have a license to use this theme: https://themeforest.net/user/motivoweb

Thank You