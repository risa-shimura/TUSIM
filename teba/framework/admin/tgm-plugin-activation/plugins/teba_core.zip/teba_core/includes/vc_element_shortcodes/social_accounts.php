<?php
vc_map(array(
	"name" => esc_html__("Social Accounts", 'teba'),
	"base" => "social_accounts",
	"category" => esc_html__('Extra Elements', 'teba'),
	"icon" => "tb-icon-for-vc fa fa-share-alt",
	"params" => array(
			array(
				'type'				=> 'param_group',
				'heading'			=> esc_html__('Social networks', 'teba'),
				'param_name'		=> 'social_networks',
				'params'			=> array(
					array(
						'type'			=> 'dropdown',
						'heading'		=> esc_html__('Social network', 'teba'),
						'param_name'	=> 'social_icons',
						'value'			=> array(
							esc_html__('Twitter', 'teba')			=> 'twitter',
							esc_html__('Facebook', 'teba')			=> 'facebook',
							esc_html__('Dribbble', 'teba')			=> 'dribbble',
							esc_html__('Deviantart', 'teba')		=> 'deviantart',
							esc_html__('Flickr', 'teba')			=> 'flickr',
							esc_html__('Instagram', 'teba')			=> 'instagram',
							esc_html__('LinkedIN', 'teba')			=> 'linkedin',
							esc_html__('Pinterest', 'teba')			=> 'pinterest',
							esc_html__('RSS', 'teba')				=> 'rss',
							esc_html__('Tumblr', 'teba')			=> 'tumblr',
							esc_html__('Vimeo', 'teba')				=> 'vimeo',
							esc_html__('YouTube', 'teba')			=> 'youtube',
							esc_html__('Skype', 'teba')				=> 'skype',
							esc_html__('Soundcloud', 'teba')		=> 'soundcloud',
							esc_html__('Behance', 'teba')			=> 'behance',
						),
					),
					array(
						'type'				=> 'vc_link',
					    'heading'           => esc_html__("URL", 'teba'),
						'param_name'		=> 'soc_url',
						'value'				=> 'url:%23|||',
						'edit_field_class'	=> 'vc_column vc_col-sm-6 no-top-padding crum_vc',
					),
				),
			 ),
	    array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("color", 'teba'),
			"param_name" => "color",
			"value" => array(
				esc_html__('colors', 'teba') => 'colors',
				esc_html__('primary', 'teba') => 'primary',
				esc_html__('white', 'teba') => 'white',
				esc_html__('grey', 'teba') => 'grey',
				esc_html__('dark', 'teba') => 'dark',
			),
		),
	       array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style", 'teba'),
				"param_name" => "style",
				"value" => array(
					esc_html__('Style 1', 'teba') => 'style1',
					esc_html__('Style 2', 'teba') => 'style2',
					esc_html__('Style 3', 'teba') => 'style3',
				),
				"description" => esc_html__('Select style in this elment.', 'teba')
	    	),
	       array(
				'type'				=> 'dropdown',
				'param_name'		=> 'alignment',
				'heading'           => esc_html__("horizontal alignment", 'teba'),
				'value'			    => array(
					esc_html__('Center', 'teba') => 'center',
					esc_html__('Left', 'teba')	=> 'left',
					esc_html__('Right', 'teba')	=> 'right'
				),
			),
			array(
				'type'				=> 'textfield',
				'param_name'		=> 'el_class',
	            'heading'           => esc_html__("Extra Class", 'teba'),
			    'description'       => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' ) 
			),
	)
));