<?php
$url = TEBA_URI . '/assets/img/process-box/';
vc_map(array(
	"name" => esc_html__("process Box", 'teba'),
	"base" => "process_box",
	"category" => esc_html__('Extra Elements', 'teba'),
	"icon" => "tb-icon-for-vc fa fa-line-chart",
	"params" => array(
	   	   array(
			'type'       => 'select_preview',
			'param_name' => 'teba_template',
			'heading'    => esc_html__('Style', 'teba'),
	        'group'      => esc_html__("Template", 'teba'),
			'value'      => array(
				array(
					'value' => 'process-box-style1',
					'label' => esc_html__('style1', 'teba'),
					'image' => $url . 'style1.jpg'
				),
				array(
	                'value' => 'process-box-style2',
					'label' => esc_html__('style2', 'teba'),
					'image' => $url . 'style2.jpg'
				),
				array(
	                'value' => 'process-box-style3',
					'label' => esc_html__('style3', 'teba'),
					'image' => $url . 'style3.jpg'
				),
			),
			'save_always' => true,
		),
	    array(
			"type" => "textfield",
			"heading" => esc_html__("Number Step", 'teba'),
			"param_name" => "number_step",
	 		"description" => esc_html__("Please, enter title in this element.", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6'
		),
		array(
			"type" => "textfield",
			"holder" => "div",
			"heading" => esc_html__("Title", 'teba'),
			"param_name" => "title",
			"description" => esc_html__("Please, enter title in this element.", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6'
		),
		array(
			"type" => "textarea_html",
			"heading" => esc_html__("Description", 'teba'),
			"param_name" => "content",
			"description" => esc_html__("Please, enter description in this element.", 'teba')
		),
		array(
			"type" => "textfield",
			"heading" => esc_html__( 'text', 'teba' ),
			"param_name" => "txt_link",
			"value" => "",
			"description" => esc_html__("Please, enter button text in this element.", 'teba'),
			'edit_field_class' => 'vc_col-sm-6'
		),
		array(
			"type" => "vc_link",
			"class" => "",
			"heading" => esc_html__( 'Link', 'teba' ),
			"param_name" => "link",
			"value" => "",
			"description" => esc_html__("Please, enter button link in this element.", 'teba'),
			'edit_field_class' => 'vc_col-sm-6'
		),
		array(
            "type" => "dropdown",
            "heading" =>esc_html__("Icon Color",'teba'),
            "param_name" => "icon_color",
			'value' => array(
				esc_html__( 'primary', 'teba' )=> '',    
                esc_html__( 'orange', 'teba' ) => 'color_orange',
                esc_html__( 'yellow', 'teba' ) => 'color_yellow',
	            esc_html__( 'green', 'teba' )  => 'color_green',
	            esc_html__( 'blue', 'teba' )   => 'color_blue',
				esc_html__( 'purple', 'teba' ) => 'color_purple',    
				esc_html__( 'pink', 'teba' )   => 'color_pink',    
				esc_html__( 'red', 'teba' )    => 'color_red', 
				esc_html__( 'dark', 'teba' )   => 'color_dark',     
            ),
			"description" => esc_html__("Please, enter icon color in this element.", 'teba'),
			'edit_field_class' => 'vc_col-sm-6'
        ),
		array(
			"type" => "textfield",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			'edit_field_class' => 'vc_col-sm-6',
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));