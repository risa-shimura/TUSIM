<?php
$url = TEBA_URI . '/assets/img/accordion/';
vc_map(array(
	"name" => esc_html__("accordion", 'teba'),
	"base" => "accordion",
	"category" => esc_html__('Extra Elements', 'teba'),
    "icon" => "tb-icon-for-vc fa fa-th-list",
	"params" => array(
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("accordion Style", 'teba'),
			"param_name" => "accordion_style",
			"value" => array(
				"Style 1" => "accordion-style1",
				"Style 2" => "accordion-style2",
				"Style 3" => "accordion-style3",
				"Style 4" => "accordion-style4",
			),
			"description" => esc_html__('Select style title section in this elment.', 'teba')
		),
	    array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image1',
	            'value'      => $url . 'style1.jpg',
				'dependency' => Array('element' => "accordion_style", 'value' => array('accordion-style1'))
		),
	    array(
	  			'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image2',
			    'value'      => $url . 'style2.jpg',
				'dependency' => Array('element' => "accordion_style", 'value' => array('accordion-style2'))
		),
	    array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image3',
			    'value'      => $url . 'style3.jpg',
				'dependency' => Array('element' => "accordion_style", 'value' => array('accordion-style3'))
		),
		array(
			'type'     	 => 'image_select',
			'heading'	 => '',
			'param_name' => 'style_image4',
			'value'      => $url . 'style4.jpg',
			'dependency' => Array('element' => "accordion_style", 'value' => array('accordion-style4'))
	),
	    array(
            'type' => 'param_group',
            'heading' => esc_html__( 'accordions', 'teba' ),
            'param_name' => 'accordion',
            'description' => esc_html__( 'Enter values for accordion item', 'teba' ),
            'value' => urlencode(
                json_encode( array(
                        array(
							'accordion_item' => '', 
							'accordion_description' => '', 
                        ),
                    ) 
                ) 
            ),
            'params' => array(
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("accordion item",'teba'),
                    "param_name" => "accordion_item",
                    'admin_label' => true,
				), 
				array(
                    "type" => "textarea",
                    "heading" => esc_html__("accordion Description",'teba'),
                    "param_name" => "accordion_description",
                ), 
            ),
        ),
	    array(
			"type" => "textfield",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));