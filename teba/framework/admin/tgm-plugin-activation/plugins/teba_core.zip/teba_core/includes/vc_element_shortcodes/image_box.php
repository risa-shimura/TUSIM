<?php
$url = TEBA_URI . '/assets/img/image-box/';
vc_map(array(
	"name" => esc_html__("Image Box", 'teba'),
	"base" => "image_box",
	"class" => "tb-demo-item",
	"category" => esc_html__('Extra Elements', 'teba'),
	"icon" => "tb-icon-for-vc fa fa-picture-o",
	"params" => array(
	    array(
	   	    'type'       => 'select_preview',
			'param_name' => 'teba_template',
			'heading'    => esc_html__('Style', 'teba'),
	        'group'      => esc_html__("Template", 'teba'),
			'value'      => array(
				array(
					'value' => 'image-box-style1',
					'label' => esc_html__('style1', 'teba'),
					'image' => $url . 'style1.jpg'
				),
				array(
	                'value' => 'image-box-style2',
					'label' => esc_html__('style2', 'teba'),
					'image' => $url . 'style2.jpg'
				),
				array(
	                'value' => 'image-box-style3',
					'label' => esc_html__('style3', 'teba'),
					'image' => $url . 'style3.jpg'
				),
				array(
	                'value' => 'image-box-style4',
					'label' => esc_html__('style4', 'teba'),
					'image' => $url . 'style4.jpg'
				),
	           array(
	                'value' => 'image-box-style5',
					'label' => esc_html__('style5', 'teba'),
					'image' => $url . 'style5.jpg'
				),
	          array(
	                'value' => 'image-box-style6',
					'label' => esc_html__('style6', 'teba'),
					'image' => $url . 'style6.jpg'
				),
	            array(
	                'value' => 'image-box-style7',
					'label' => esc_html__('style7', 'teba'),
					'image' => $url . 'style7.jpg'
				),
	           array(
	                'value' => 'image-box-style8',
					'label' => esc_html__('style8', 'teba'),
					'image' => $url . 'style8.jpg'
				),
	           array(
	                'value' => 'image-box-style9',
					'label' => esc_html__('style9', 'teba'),
					'image' => $url . 'style9.jpg'
				),
	           array(
	                'value' => 'image-box-style10',
					'label' => esc_html__('style10', 'teba'),
					'image' => $url . 'style10.jpg'
				),
	            array(
	                'value' => 'image-box-style11',
					'label' => esc_html__('style11', 'teba'),
					'image' => $url . 'style11.jpg'
				),
			),
			'save_always' => true,
		),
		array(
			"type" => "attach_image",
			"class" => "",
			"heading" => esc_html__("Image", 'teba'),
			"param_name" => "image",
			"value" => "",
			"description" => esc_html__("Select image for demo item.", 'teba')
		),
	   
		/* Start Icon */
		  array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon library', 'teba' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'teba' ) => 'fontawesome',
                esc_html__( 'Linecons', 'teba' )     => 'linecons',
	            esc_html__( 'Ionicons', 'teba' )     => 'ionicons',
				esc_html__( 'P7 Stroke', 'teba' )    => 'pe7stroke',
	            esc_html__( 'ET-line', 'teba' )      => 'etline',
	            esc_html__( 'Animated', 'teba' )     => 'animated'     
            ),
            'param_name'  => 'icon',
			'description' => esc_html__( 'Select icon library.', 'teba' ),
			"dependency" => array(
				"element"=>"teba_template",
				"value"=> array('image-box-style1','image-box-style2','image-box-style3','image-box-style4','image-box-style5','image-box-style6','image-box-style7','image-box-style8','image-box-style9')
			 ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_fontawesome',
	        'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type'      => 'fontawesome',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value'   => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	   array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_linecons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'linecons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'linecons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_ionicons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'ionicons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'ionicons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	   array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_pe7stroke',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'pe7stroke',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'pe7stroke',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_etline',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'etline',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'etline',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
       array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_animated',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'animated',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'animated',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	    array(
			'type'       => 'dropdown',
			'param_name' => 'animation',
			'heading'    => esc_html__( 'Animate SVG Icon?', 'teba' ),
			'value'      => array(
				esc_html__( 'No', 'teba' )  => '',
				esc_html__( 'Yes', 'teba' ) => 'yes'
			),
			'dependency' => array(
				'element' => 'icon',
				'value'   => 'animated',
			),
			'edit_field_class' => 'vc_col-sm-4'
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'hover_animation',
			'heading'    => esc_html__( 'Restart Animation on Hover', 'teba' ),
			'value'      => array(
				esc_html__( 'No', 'teba' )  => '',
				esc_html__( 'Yes', 'teba' ) => 'yes'
			),
			'dependency' => array(
				'element' => 'icon',
				'value'   => 'animated',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'       => 'textfield',
			'param_name' => 'animation_delay',
			'heading'    => esc_html__( 'SVG Animation Delay', 'teba' ),
	        "description"=> esc_html__("In Milliseconds Default:200 .", 'teba'),
			'dependency' => array(
				'element' => 'icon',
				'value'   => 'animated',
			),
	        'edit_field_class' => 'vc_col-sm-4',
		),
        /* End Icon */ 
		array(
			"type" => "textfield",
			"holder" => "div",
			"heading" => esc_html__("Title", 'teba'),
			"param_name" => "title_box",
			"value" => "",
			"description" => esc_html__("Please, enter title for demo item.", 'teba')
		),
	    array(
			"type" => "textarea_html",
			"class" => "",
			"heading" => esc_html__("Description", 'teba'),
			"param_name" => "content_box",
			"value" => "",
			"description" => esc_html__("Please, enter description in this element.", 'teba'),
		),
	   array(
			"type" => "vc_link",
			"class" => "",
			"heading" => esc_html__( 'Link', 'teba' ),
			"param_name" => "link_box",
			"value" => "",
			"description" => esc_html__("Please, enter button link in this element.", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			"type" => "textfield",
			"heading" => esc_html__("Link Text", 'teba'),
			"param_name" => "txt_link_box",
			"value" => "",
			"description" => esc_html__("Please, enter text link for demo item. ex:Read More", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6',
		),
		array(
		    "type" => "dropdown",
			"heading" => esc_html__("background color", 'teba'),
			"param_name" => "box_bg_color",
			"value" => array(
				esc_html__( 'primary', 'teba' )=> '',    
                esc_html__( 'orange', 'teba' ) => 'color_orange',
                esc_html__( 'yellow', 'teba' ) => 'color_yellow',
	            esc_html__( 'green', 'teba' )  => 'color_green',
	            esc_html__( 'blue', 'teba' )   => 'color_blue',
				esc_html__( 'purple', 'teba' ) => 'color_purple',    
				esc_html__( 'pink', 'teba' )   => 'color_pink',    
				esc_html__( 'red', 'teba' )    => 'color_red', 
				esc_html__( 'dark', 'teba' )   => 'color_dark',  
			),
			"dependency" => array(
				"element"=>"teba_template",
				"value"=> array('image-box-style1','image-box-style2','image-box-style3','image-box-style4','image-box-style5','image-box-style6','image-box-style7','image-box-style8','image-box-style9','image-box-style10')
			 ),
			 'edit_field_class' => 'vc_col-sm-6',
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' ),
			'edit_field_class' => 'vc_col-sm-6',
		),
	)
));