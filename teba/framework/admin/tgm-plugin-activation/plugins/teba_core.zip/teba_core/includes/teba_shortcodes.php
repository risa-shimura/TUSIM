<?php
/* Add extra type on visual composer */
require_once TEBA_INCLUDES.'types/teba_template.php';
require_once TEBA_INCLUDES.'types/teba_template_img.php';