<?php
vc_map(array(
	"name" => esc_html__("Video Button", 'teba'),
	"base" => "video_button",
	"category" => esc_html__('Extra Elements', 'teba'),
	"icon" => "tb-icon-for-vc fa fa-play-circle",
	"params" => array(
		array(
			"type" => "textfield",
			"heading" => esc_html__("Video Link", 'teba'),
			"param_name" => "video_link",
			"value" => "",
			"description" => esc_html__("Please, enter video link in this element.", 'teba')
		),
	    array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("color", 'teba'),
			"param_name" => "color",
			"value" => array(
	           "light"        => "light",
				"primary"     => "primary",
				"dark"        => "dark",
			),
	       'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Button Position", 'teba'),
			"param_name" => "position",
			"value" => array(
				"center" => "dir_center",
				"right"  => "dir_right",
				"left"   => "dir_left",
			),
	        'edit_field_class' => 'vc_col-sm-6'
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));