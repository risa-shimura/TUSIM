<?php
$url = TEBA_URI . '/assets/img/team/';
vc_map ( array (
	"name" => 'Team member',
	"base" => "team",
    "icon" => "tb-icon-for-vc fa fa-user",
	"category" => esc_html__( 'Extra Elements', 'teba' ), 
	'admin_enqueue_js' => array(TEBA_JS.'customvc.js'),
	"params" => array (
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Template", 'teba'),
			"param_name" => "tpl",
			"value" => array(
				"Template 1" => "tpl1",
				"Template 2" => "tpl2",
				"Template 3" => "tpl3",
			),
			"description" => esc_html__('Select template of posts display in this element.', 'teba'),
			"group"       => esc_html__("Style", 'teba'),
		),
	    array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image1',
	            'value'      => $url . 'style1.jpg',
				'dependency' => Array('element' => "tpl", 'value' => array('tpl1')),
				"group"      => esc_html__("Style", 'teba'),
		),
	    array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image2',
			    'value'      => $url . 'style2.jpg',
				'dependency' => Array('element' => "tpl", 'value' => array('tpl2')),
				"group"      => esc_html__("Style", 'teba'),
		),
	    array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image3',
			    'value'      => $url . 'style3.jpg',
				'dependency' => Array('element' => "tpl", 'value' => array('tpl3')),
				"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			'type'        => 'attach_image',
			'param_name'  => 'image',
			'heading'     => esc_html__( 'Team Member Image', 'teba' )
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'name',
			'heading'     => esc_html__( 'Team Member Name', 'teba' ),
			'admin_label' => true,
	        'edit_field_class' => 'vc_col-sm-6'
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'position',
			'heading'     => esc_html__( 'Team Member Position', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'facebook_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Facebook link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'twitter_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Twitter link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'linkedin_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Linkedin link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'behance_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Behance link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'pinterest_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Pinterest link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'instagram_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Instagram link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'flickr_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Flickr link', 'teba' ),
	         'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			'type'        => 'textfield',
			'param_name'  => 'skype_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Skype link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			'type'        => 'textfield',
			'param_name'  => 'youtube_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Youtube link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			'type'        => 'textfield',
			'param_name'  => 'extra_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'External link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	)
));