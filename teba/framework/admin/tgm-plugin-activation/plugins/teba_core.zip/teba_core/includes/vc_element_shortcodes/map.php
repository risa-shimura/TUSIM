<?php
vc_map(array(
    "name" => 'Google Maps',
    "base" => "maps",
    "category" => esc_html__('Extra Elements', 'teba'),
    "icon" => "tb-icon-for-vc fa fa-map-marker",
    "description" => esc_html__('Google Maps API', 'teba'),
    "params" => array(
        array(
            "type" => "textfield",
            "heading" => esc_html__('API Key', 'teba'),
            "param_name" => "api",
            "value" => '',
            "description" => esc_html__('Enter you api key of map, get key from (https://console.developers.google.com)', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Address', 'teba'),
            "param_name" => "address",
            "value" => 'New York, United States',
            "description" => esc_html__('Enter address of Map', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Coordinate', 'teba'),
            "param_name" => "coordinate",
            "value" => '',
            "description" => esc_html__('Enter coordinate of Map, format input (latitude, longitude)', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Click Show Info window', 'teba'),
            "param_name" => "infoclick",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Marker", 'teba'),
            "description" => esc_html__('Click a marker and show info window (Default Show).', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Marker Coordinate', 'teba'),
            "param_name" => "markercoordinate",
            "value" => '',
            "group" => esc_html__("Marker", 'teba'),
            "description" => esc_html__('Enter marker coordinate of Map, format input (latitude, longitude)', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Marker Title', 'teba'),
            "param_name" => "markertitle",
            "value" => '',
            "group" => esc_html__("Marker", 'teba'),
            "description" => esc_html__('Enter Title Info windows for marker', 'teba')
        ),
        array(
            "type" => "textarea",
            "heading" => esc_html__('Marker Description', 'teba'),
            "param_name" => "markerdesc",
            "value" => '',
            "group" => esc_html__("Marker", 'teba'),
            "description" => esc_html__('Enter Description Info windows for marker', 'teba')
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__('Marker Icon', 'teba'),
            "param_name" => "markericon",
            "value" => '',
            "group" => esc_html__("Marker", 'teba'),
            "description" => esc_html__('Select image icon for marker', 'teba')
        ),
        array(
            "type" => "textarea_raw_html",
            "heading" => esc_html__('Marker List', 'teba'),
            "param_name" => "markerlist",
            "value" => '',
            "group" => esc_html__("Multiple Marker", 'teba'),
            "description" => esc_html__('[{"coordinate":"41.058846,-73.539423","icon":"","title":"title demo 1","desc":"desc demo 1"},{"coordinate":"40.975699,-73.717636","icon":"","title":"title demo 2","desc":"desc demo 2"},{"coordinate":"41.082606,-73.469718","icon":"","title":"title demo 3","desc":"desc demo 3"}]', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Info Window Max Width', 'teba'),
            "param_name" => "infowidth",
            "value" => '200',
            "group" => esc_html__("Marker", 'teba'),
            "description" => esc_html__('Set max width for info window', 'teba')
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Map Type", 'teba'),
            "param_name" => "type",
            "value" => array(
                "ROADMAP" => "ROADMAP",
                "HYBRID" => "HYBRID",
                "SATELLITE" => "SATELLITE",
                "TERRAIN" => "TERRAIN"
            ),
            "description" => esc_html__('Select the map type.', 'teba')
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style Template", 'teba'),
            "param_name" => "style",
            "value" => array(
                "Subtle Grayscale" => "Subtle-Grayscale",
                "Shades of Grey" => "Shades-of-Grey",
                "Blue water" => "Blue-water",
                "Pale Dawn" => "Pale-Dawn",
                "Blue Essence" => "Blue-Essence",
                "Apple Maps-esque" => "Apple-Maps-esque",
            ),
            "group" => esc_html__("Map Style", 'teba'),
            "description" => 'Select your heading size for title.'
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Zoom', 'teba'),
            "param_name" => "zoom",
            "value" => '13',
            "description" => esc_html__('zoom level of map, default is 13', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Width', 'teba'),
            "param_name" => "width",
            "value" => 'auto',
            "description" => esc_html__('Width of map without pixel, default is auto', 'teba')
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__('Height', 'teba'),
            "param_name" => "height",
            "value" => '350px',
            "description" => esc_html__('Height of map without pixel, default is 350px', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Scroll Wheel', 'teba'),
            "param_name" => "scrollwheel",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('If false, disables scrollwheel zooming on the map. The scrollwheel is disable by default.', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Pan Control', 'teba'),
            "param_name" => "pancontrol",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('Show or hide Pan control.', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Zoom Control', 'teba'),
            "param_name" => "zoomcontrol",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('Show or hide Zoom Control.', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Scale Control', 'teba'),
            "param_name" => "scalecontrol",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('Show or hide Scale Control.', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Map Type Control', 'teba'),
            "param_name" => "maptypecontrol",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('Show or hide Map Type Control.', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Street View Control', 'teba'),
            "param_name" => "streetviewcontrol",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('Show or hide Street View Control.', 'teba')
        ),
        array(
            "type" => "checkbox",
            "heading" => esc_html__('Over View Map Control', 'teba'),
            "param_name" => "overviewmapcontrol",
            "value" => array(
                esc_html__("Yes, please", 'teba') => true
            ),
            "group" => esc_html__("Controls", 'teba'),
            "description" => esc_html__('Show or hide Over View Map Control.', 'teba')
        )
    )
));