<?php
vc_map ( array (
	"name" => 'Blog Carousel',
	"base" => "blog_carousel",
	"icon" => "tb-icon-for-vc fa fa-qrcode",
	"category" => esc_html__( 'Extra Elements', 'teba' ), 
	'admin_enqueue_js' => array(TEBA_JS.'customvc.js'),
	"params" => array (
		array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Template", 'teba'),
				"param_name" => "tpl",
	            "admin_label" => true,
				"value" => array(
	                "Image Middle"  => "tpl1",
					"Image Overlay" => "tpl2",
					"Without Image" => "tpl3",
				),
				"description" => esc_html__('Select template of posts display in this element.', 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Large devices", 'teba'),
			"param_name" => "col_lg",
			"value" => "",
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__("Please, enter number Columns Large devices Desktops (>=1200px) in this element. Default: 3", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Column Medium device", 'teba'),
			"param_name" => "col_md",
			"value" => "",
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__("Please, enter number Columns Medium devices Desktops (>=992px) in this element. Default: 3", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Small devices", 'teba'),
			"param_name" => "col_sm",
			"value" => "",
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__("Please, enter number Columns Small devices Tablets (>=768px) in this element. Default: 2", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns x-small device", 'teba'),
			"param_name" => "col_xs",
			"value" => "",
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__("Please, enter number Columns Extra small devices Phones (<768px) in this element. Default: 1", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Item Space", 'teba'),
			"param_name" => "item_space",
			"value" => "",
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__("Please, enter number space between items in this element. Default: 30", 'teba')
		),
	    array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("SmartSpeed", 'teba'),
			"param_name" => "smartspeed",
			"value" => "",
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__("Please, enter number smartSpeed(Speed Calculate. More info to come..) in this element. Default: 500", 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Loop", 'teba'),
			"param_name" => "loop",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
	       'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Inifnity loop. Duplicate last and first items to get loop illusion.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("autoplay", 'teba'),
			"param_name" => "autoplay",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Autoplay.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Nav", 'teba'),
			"param_name" => "nav",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Show next/prev buttons.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Nav Position", 'teba'),
			"param_name" => "nav_position",
			"value" => array(
				"Middle" => "nav-middle",
	            "right" => "nav-right",
				"left" => "nav-left"
			),
			"dependency" => array(
				"element"=>"nav",
				"value"=> "true"
			), 
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Select position next/prev buttons.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots", 'teba'),
			"param_name" => "dots",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Show dots navigation.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots Direction Position", 'teba'),
			"param_name" => "dots_dir_position",
			"value" => array(
				"center" => "dots-center",
				"Right" => "dots-right",
				"Left" => "dots-left",
			),
			"dependency" => array(
				"element"=>"dots",
				"value"=> "true"
			),
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Select direction position dots navigation.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots and Nav Color", 'teba'),
			"param_name" => "dots_nav_color",
			"value" => array(
				"primary"   => "primary",
				"dark"      => "dark",
				"light"     => "light"
			),
	        'edit_field_class' => 'vc_col-sm-3',
			"description" => esc_html__('Select color dots and nav.', 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
		array (
			"type" => "mo_taxonomy",
			"taxonomy" => "category",
			"heading" => esc_html__( "Categories", 'teba' ),
			"param_name" => "category",
			"group" => esc_html__("Build Query", 'teba'),
			"description" => esc_html__( "Note: By default, all your projects will be displayed. If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'teba' )
	   ),
		array (
			"type" => "textfield",
			"heading" => esc_html__( 'Count', 'teba' ),
			"param_name" => "posts_per_page",
			'value' => '',
			"group" => esc_html__("Build Query", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6',
			"description" => esc_html__( 'The number of posts to display on each page. Set to "-1" for display all posts on the page.', 'teba' )
		),
	     array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Excerpt Length", 'teba'),
			"param_name" => "excerpt_lenght",
			"value" => "",
			"group" => esc_html__("Build Query", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6',
			"description" => esc_html__("Please, Enter number excerpt lenght of post in this element. Default: 14", 'teba')
		),
		array (
			"type" => "dropdown",
			"heading" => esc_html__( 'Order by', 'teba' ),
			"param_name" => "orderby",
			"value" => array (
					"None" => "none",
					"Title" => "title",
					"Date" => "date",
					"ID" => "ID"
			),
			"group" => esc_html__("Build Query", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6',
			"description" => esc_html__( 'Order by ("none", "title", "date", "ID").', 'teba' )
		),
		array (
			"type" => "dropdown",
			"heading" => esc_html__( 'Order', 'teba' ),
			"param_name" => "order",
			"value" => Array (
					"None" => "none",
					"ASC" => "ASC",
					"DESC" => "DESC"
			),
			"group" => esc_html__("Build Query", 'teba'),
	        'edit_field_class' => 'vc_col-sm-6',
			"description" => esc_html__( 'Order ("None", "Asc", "Desc").', 'teba' )
		),
	)
));