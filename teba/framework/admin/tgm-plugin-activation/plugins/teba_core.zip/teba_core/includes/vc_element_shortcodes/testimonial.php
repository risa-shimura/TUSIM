<?php
$url = TEBA_URI . '/assets/img/testimonial/';
vc_map( array(
	"name" => 'Testimonial',
	"base" => "testimonial",
    "icon" => "tb-icon-for-vc fa fa-comments",
	"category" => esc_html__( 'Extra Elements', 'teba' ), 
    "as_parent" => array('only' => 'single_testimonial'),
    "content_element" => true,
    "show_settings_on_create" => false,
    "is_container" => true,
    "js_view" => 'VcColumnView',
	"params" => array(
	  	array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Template", 'teba'),
			"heading" => esc_html__("Template", 'teba'),
			"param_name" => "tpl",
			"value" => array(
				"Template 1" => "tpl1",
				"Template 2" => "tpl2",
				"Template 3" => "tpl3",
	            "Template 4" => "tpl4",
	            "Template 5" => "tpl5"
			),
			"group" => esc_html__("Style", 'teba'),
			"description" => esc_html__('Select template of posts display in this element.', 'teba')
		),
	     array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style1',
			'value'      => $url . 'style1.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl1')),
			"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style2',
			 'value'      => $url . 'style2.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl2')),
			"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style3',
		    'value'      => $url . 'style3.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl3')),
			"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style4',
			'value'      => $url . 'style4.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl4')),
			"group"      => esc_html__("Style", 'teba'),
		),
	   array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style5',
			'value'      => $url . 'style5.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl5')),
			"group"      => esc_html__("Style", 'teba'),
		),
	 	array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("text color", 'teba'),
			"param_name" => "text_color",
			"value" => array(
				"Black" => "black_txt",
				"White"  => "white_txt",
			),
			"description" => esc_html__('the color of text in testimonial carousel.', 'teba'),
	        "group"      => esc_html__("Style", 'teba'),
		),
	    array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' ),
	        "group"      => esc_html__("Style", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Large devices", 'teba'),
			"param_name" => "col_lg",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Large devices Desktops (>=1200px) in this element. Default: 1", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Medium devices", 'teba'),
			"param_name" => "col_md",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Medium devices Desktops (>=992px) in this element. Default: 1", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Small devices", 'teba'),
			"param_name" => "col_sm",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Small devices Tablets (>=768px) in this element. Default: 1", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Extra small", 'teba'),
			"param_name" => "col_xs",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Extra small devices Phones (<768px) in this element. Default: 1", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
	    array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("SmartSpeed", 'teba'),
			"param_name" => "smartspeed",
			"value" => "",
			"description" => esc_html__("Please, enter number smartSpeed(Speed Calculate. More info to come..) in this element. Default: 500", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Item Space", 'teba'),
			"param_name" => "item_space",
			"value" => "",
			"description" => esc_html__("Please, enter number space between items in this element. Default:0", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Loop", 'teba'),
			"param_name" => "loop",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Inifnity loop. Duplicate last and first items to get loop illusion.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("autoplay", 'teba'),
			"param_name" => "autoplay",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Autoplay.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Nav", 'teba'),
			"param_name" => "nav",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Show next/prev buttons.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"heading" => esc_html__("Nav Position", 'teba'),
			"param_name" => "nav_position",
			"value" => array(
				"Middle" => "nav-middle",
	            "right" => "nav-right",
				"left" => "nav-left",
			),
			"dependency" => array(
				"element"=>"nav",
				"value"=> "true"
			),
			"description" => esc_html__('Select position next/prev buttons.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots", 'teba'),
			"param_name" => "dots",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Show dots navigation.', 'teba'),
	       'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	       "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots Direction Position", 'teba'),
			"param_name" => "dots_dir_position",
			"value" => array(
				"center" => "dots-center",
				"Right" => "dots-right",
				"Left" => "dots-left",
			),
			"dependency" => array(
				"element"=>"dots",
				"value"=> "true"
			),
			"description" => esc_html__('Select direction position dots navigation.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots and Nav Color", 'teba'),
			"param_name" => "dots_nav_color",
			"value" => array(
				"primary"   => "primary",
				"dark"      => "dark",
				"light"     => "light",
			),
			"description" => esc_html__('Select color dots and nav.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
     ),
 ) );

vc_map( array(
    "name" => __("Single Testimonial", "teba"),
    "base" => "single_testimonial",
	"icon" => "tb-icon-for-vc fa fa-quote-right",
    "content_element" => true,
    "as_child" => array('only' => 'testimonial'),
    "show_settings_on_create" => true,
    "params" => array(
	    array(
			'type'        => 'attach_image',
			'param_name'  => 'image',
			'heading'     => esc_html__( 'Team Member Image', 'teba' )
		),
	   array(
			'type' => 'textfield',
			'param_name' => 'author',
			'heading' => esc_html__( 'Author', 'teba' ),
			'edit_field_class' => 'vc_column-with-padding vc_col-sm-6',
			'admin_label' => true,
		),
		array(
			'type'        => 'textfield',
			'param_name'   => 'position',
			'heading'      => esc_html__( 'position', 'teba' ),
			'edit_field_class' => 'vc_col-sm-6',
		),
		array(
			'type' => 'textfield',
			'param_name' => 'title',
			'heading' => esc_html__( 'Title', 'teba' ),
		),
		array(
			'type'        => 'textarea_html',
			'param_name'  => 'details',
			'heading'     => esc_html__( 'Blockquote', 'teba' ),
		),
	   array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Rating', 'teba' ),
            'value' => array(
	            esc_html__("no", 'teba')      => "false",
				esc_html__("yes", 'teba')      => "true",
	         ),
            'param_name' => 'rating',
        ),
	    array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Star Rating', 'teba' ),
            'value' => array(
				esc_html__("Five", 'teba')  => "five",
				esc_html__("Four", 'teba')  => "four",
				esc_html__("Three", 'teba') => "three",
				esc_html__("Two", 'teba')   => "two",
	            esc_html__("One", 'teba')   => "one"),
            'param_name' => 'star_rating',
	        'dependency' => array(
				'element' => 'rating',
				'value'   => 'true',
			),
        ),
      ),
 ) );
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_testimonial extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Single_testimonial extends WPBakeryShortCode {
    }
}