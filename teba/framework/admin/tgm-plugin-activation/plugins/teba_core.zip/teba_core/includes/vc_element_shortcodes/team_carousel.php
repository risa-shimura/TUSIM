<?php
$url = TEBA_URI . '/assets/img/team/';
vc_map( array(
	"name" => 'Team Carousel',
	"base" => "team_carousel",
    "icon" => "tb-icon-for-vc fa fa-users",
	"category" => esc_html__( 'Extra Elements', 'teba' ), 
    "as_parent" => array('only' => 'single_team_carousel'),
    "content_element" => true,
    "show_settings_on_create" => false,
    "is_container" => true,
    "js_view" => 'VcColumnView',
	"params" => array(
	    	array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Template", 'teba'),
			"heading" => esc_html__("Template", 'teba'),
			"param_name" => "tpl",
			"value" => array(
				"Template 1" => "tpl1",
				"Template 2" => "tpl2",
				"Template 3" => "tpl3",
			),
			"group" => esc_html__("Style", 'teba'),
			"description" => esc_html__('Select template of posts display in this element.', 'teba')
		),
	     array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style1',
			'value'      => $url . 'style1.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl1')),
			"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style2',
			 'value'      => $url . 'style2.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl2')),
			"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			'type'	     => 'image_select',
			'heading'	 => '',
			'param_name' => 'style3',
		    'value'      => $url . 'style3.jpg',
			'dependency' => Array('element' => "tpl", 'value' => array('tpl3')),
			"group"      => esc_html__("Style", 'teba'),
		),
	    array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' ),
	        "group"      => esc_html__("Style", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Large devices", 'teba'),
			"param_name" => "col_lg",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Large devices Desktops (>=1200px) in this element. Default: 4", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Medium devices", 'teba'),
			"param_name" => "col_md",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Medium devices Desktops (>=992px) in this element. Default: 2", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Small devices", 'teba'),
			"param_name" => "col_sm",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Small devices Tablets (>=768px) in this element. Default: 1", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Columns Extra small", 'teba'),
			"param_name" => "col_xs",
			"value" => "",
			"description" => esc_html__("Please, enter number Columns Extra small devices Phones (<768px) in this element. Default: 1", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
	    array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("SmartSpeed", 'teba'),
			"param_name" => "smartspeed",
			"value" => "",
			"description" => esc_html__("Please, enter number smartSpeed(Speed Calculate. More info to come..) in this element. Default: 500", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Item Space", 'teba'),
			"param_name" => "item_space",
			"value" => "",
			"description" => esc_html__("Please, enter number space between items in this element. Default:0", 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Loop", 'teba'),
			"param_name" => "loop",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Inifnity loop. Duplicate last and first items to get loop illusion.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("autoplay", 'teba'),
			"param_name" => "autoplay",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Autoplay.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Nav", 'teba'),
			"param_name" => "nav",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Show next/prev buttons.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"heading" => esc_html__("Nav Position", 'teba'),
			"param_name" => "nav_position",
			"value" => array(
				"Middle" => "nav-middle",
	            "right" => "nav-right",
				"left" => "nav-left",
			),
			"dependency" => array(
				"element"=>"nav",
				"value"=> "true"
			),
			"description" => esc_html__('Select position next/prev buttons.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots", 'teba'),
			"param_name" => "dots",
			"value" => array(
				"Disable" => "false",
				"Enable" => "true",
			),
			"description" => esc_html__('Show dots navigation.', 'teba'),
	       'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	       "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots Direction Position", 'teba'),
			"param_name" => "dots_dir_position",
			"value" => array(
				"center" => "dots-center",
				"Right" => "dots-right",
				"Left" => "dots-left",
			),
			"dependency" => array(
				"element"=>"dots",
				"value"=> "true"
			),
			"description" => esc_html__('Select direction position dots navigation.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots and Nav Color", 'teba'),
			"param_name" => "dots_nav_color",
			"value" => array(
				"primary"   => "primary",
				"dark"      => "dark",
				"light"     => "light",
			),
			"description" => esc_html__('Select color dots and nav.', 'teba'),
	        'edit_field_class' => 'vc_column-with-padding vc_col-sm-3',
	        "group"      => esc_html__("Carousel Option", 'teba'),
		),
     ),
 ) );

vc_map( array(
    "name" => __("Single Team Carousel", "teba"),
    "base" => "single_team_carousel",
	"icon" => "tb-icon-for-vc fa fa-user",
    "content_element" => true,
    "as_child" => array('only' => 'team_carousel'),
    "show_settings_on_create" => true,
    "params" => array(
	    array(
			'type'        => 'attach_image',
			'param_name'  => 'image',
			'heading'     => esc_html__( 'Team Member Image', 'teba' )
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'name',
			'heading'     => esc_html__( 'Team Member Name', 'teba' ),
			'admin_label' => true,
	        'edit_field_class' => 'vc_col-sm-6'
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'position',
			'heading'     => esc_html__( 'Team Member Position', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	     array(
			'type'        => 'textfield',
			'param_name'  => 'facebook_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Facebook link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'twitter_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Twitter link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'linkedin_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Linkedin link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'behance_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Behance link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'pinterest_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Pinterest link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'instagram_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Instagram link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	    array(
			'type'        => 'textfield',
			'param_name'  => 'flickr_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Flickr link', 'teba' ),
	         'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			'type'        => 'textfield',
			'param_name'  => 'skype_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Skype link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			'type'        => 'textfield',
			'param_name'  => 'youtube_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'Youtube link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	   array(
			'type'        => 'textfield',
			'param_name'  => 'extra_link',
        	"group"       => esc_html__("socia Link", 'teba'),
			'heading'     => esc_html__( 'External link', 'teba' ),
	        'edit_field_class' => 'vc_col-sm-6'
		),
	
	
      ),
 ) );
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_team_carousel extends WPBakeryShortCodesContainer {
    }
}
if ( class_exists( 'WPBakeryShortCode' ) ) {
    class WPBakeryShortCode_Single_team_carousel extends WPBakeryShortCode {
    }
}