<?php
vc_map(array(
	"name" => esc_html__("Ad Banner", 'teba'),
	"base" => "ad_banner",
	"category" => esc_html__('Extra Elements', 'teba'),
	"icon" => "tb-icon-for-vc fa fa-television",
	"params" => array(
		array(
			"type" => "attach_image",
			"class" => "",
			"heading" => esc_html__("Image", 'teba'),
			"param_name" => "image",
			"value" => "",
			"description" => esc_html__("Select box image in this element.", 'teba')
		),
	   array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Title", 'teba'),
			"param_name" => "title",
			"value" => "",
			"description" => esc_html__("Please, enter title in this element.", 'teba')
		),
       array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Suptitle", 'teba'),
			"param_name" => "ad_suptitle",
			"value" => "",
			"description" => esc_html__("Please, enter suptitle in this element.", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Description", 'teba'),
			"param_name" => "ad_content",
			"value" => "",
			"description" => esc_html__("Please, enter description in this element.", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Link", 'teba'),
			"param_name" => "link",
			"value" => "",
			"description" => esc_html__("Please, enter link in this element.", 'teba')
		),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__ ( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));