<?php
$url = TEBA_URI . '/assets/img/list/';
vc_map(array(
	"name" => esc_html__("List", 'teba'),
	"base" => "list",
	"category" => esc_html__('Extra Elements', 'teba'),
    "icon" => "tb-icon-for-vc fa fa-list",
	"params" => array(
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("List Style", 'teba'),
			"param_name" => "list_style",
			"value" => array(
				"Style 1" => "list-style1",
				"Style 2" => "list-style2",
				"Style 3" => "list-style3",
				"Style 4" => "list-style4",
				"Style 5" => "list-style5",
				"Style 6" => "list-style6",

			),
			"description" => esc_html__('Select style title section in this elment.', 'teba')
		),
	    array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image1',
	            'value' => $url . 'style1.jpg',
				'dependency' => Array('element' => "list_style", 'value' => array('list-style1'))
		),
	    array(
	  			'type'	=> 'image_select',
				'heading'	=> '',
				'param_name'	=> 'style_image2',
			    'value' => $url . 'style2.jpg',
				'dependency' => Array('element' => "list_style", 'value' => array('list-style2'))
		),
	    array(
				'type'	=> 'image_select',
				'heading'	=> '',
				'param_name'	=> 'style_image3',
			    'value' => $url . 'style3.jpg',
				'dependency' => Array('element' => "list_style", 'value' => array('list-style3'))
		),
	    array(
				'type'	=> 'image_select',
				'heading'	=> '',
				'param_name'	=> 'style_image4',
			    'value' => $url . 'style4.jpg',
				'dependency' => Array('element' => "list_style", 'value' => array('list-style4'))
		),
	    array(
				'type'	=> 'image_select',
				'heading'	=> '',
				'param_name'	=> 'style_image5',
			    'value' => $url . 'style5.jpg',
				'dependency' => Array('element' => "list_style", 'value' => array('list-style5'))
		),
	    array(
				'type'	=> 'image_select',
				'heading'	=> '',
				'param_name'	=> 'style_image6',
			    'value' => $url . 'style6.jpg',
				'dependency' => Array('element' => "list_style", 'value' => array('list-style6'))
		),
	    array(
            'type' => 'param_group',
            'heading' => esc_html__( 'Lists', 'teba' ),
            'param_name' => 'list',
            'description' => esc_html__( 'Enter values for list item', 'teba' ),
            'value' => urlencode(
                json_encode( array(
                        array(
							'list_item' => '', 
							'list_description' => '', 
                        ),
                    ) 
                ) 
            ),
            'params' => array(
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("List item",'teba'),
                    "param_name" => "list_item",
                    'admin_label' => true,
				), 
				array(
                    "type" => "textarea",
                    "heading" => esc_html__("List Description",'teba'),
                    "param_name" => "list_description",
                ), 
            ),
        ),
	    array(
			"type" => "textfield",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));