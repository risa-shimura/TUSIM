<?php
	vc_map ( array (
		"name" => 'Product Carousel',
		"base" => "product_carousel",
        "class" => "tb-products-grid",
		"icon" => "tb-icon-for-vc fa fa-cart-plus",
		"category" => esc_html__( 'Extra Elements', 'teba' ), 
		"params" => array (
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Template", 'teba'),
				"param_name" => "tpl",
				"value" => array(
					"Template 1" => "tpl1",
					"Template 2" => "tpl2",
				),
				"description" => esc_html__('Select template of posts display in this element.', 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Columns Large devices", 'teba'),
				"param_name" => "col_lg",
				"value" => "",
				"description" => esc_html__("Please, enter number Columns Large devices Desktops (>=1200px) in this element. Default: 4", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Columns Medium devices", 'teba'),
				"param_name" => "col_md",
				"value" => "",
				"description" => esc_html__("Please, enter number Columns Medium devices Desktops (>=992px) in this element. Default: 3", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Columns Small devices", 'teba'),
				"param_name" => "col_sm",
				"value" => "",
				"description" => esc_html__("Please, enter number Columns Small devices Tablets (>=768px) in this element. Default: 2", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Columns Extra small devices", 'teba'),
				"param_name" => "col_xs",
				"value" => "",
				"description" => esc_html__("Please, enter number Columns Extra small devices Phones (<768px) in this element. Default: 1", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Item Space", 'teba'),
				"param_name" => "item_space",
				"value" => "",
				"description" => esc_html__("Please, enter number space between items in this element. Default: 30", 'teba')
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Loop", 'teba'),
				"param_name" => "loop",
				"value" => array(
					"Disable" => "false",
					"Enable" => "true",
				),
				"description" => esc_html__('Inifnity loop. Duplicate last and first items to get loop illusion.', 'teba')
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("autoplay", 'teba'),
				"param_name" => "autoplay",
				"value" => array(
					"Disable" => "false",
					"Enable" => "true",
				),
				"description" => esc_html__('Autoplay.', 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("SmartSpeed", 'teba'),
				"param_name" => "smartspeed",
				"value" => "",
				"description" => esc_html__("Please, enter number smartSpeed(Speed Calculate. More info to come..) in this element. Default: 500", 'teba')
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Nav", 'teba'),
				"param_name" => "nav",
				"value" => array(
					"Disable" => "false",
					"Enable" => "true",
				),
				"description" => esc_html__('Show next/prev buttons.', 'teba')
			),
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Dots", 'teba'),
				"param_name" => "dots",
				"value" => array(
					"Disable" => "false",
					"Enable" => "true",
				),
				"description" => esc_html__('Show dots navigation.', 'teba')
			),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots Direction Position", 'teba'),
			"param_name" => "dots_dir_position",
			"value" => array(
				"center" => "dots-center",
				"Right" => "dots-right",
				"Left" => "dots-left",
			),
			"dependency" => array(
				"element"=>"dots",
				"value"=> "true"
			),
			"description" => esc_html__('Select direction position dots navigation.', 'teba')
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Dots and Nav Color", 'teba'),
			"param_name" => "dots_nav_color",
			"value" => array(
		        "primary"   => "primary",
				"dark"      => "dark",
				"light"     => "light",
			),
			"description" => esc_html__('Select color dots and nav.', 'teba')
		),
		
		
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'teba'),
				"param_name" => "el_class",
				"value" => "",
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
			),
			array (
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__( "Show", 'teba' ),
					"param_name" => "show",
					"value" => array (
							"All Products"      => "all_products",
							"Featured Products" => "featured",
							"On-sale Products"  => "onsale",
					),
					"group" => esc_html__("Build Query", 'teba'),
					"description" => esc_html__( "Select show product type in this elment", 'teba' )
			),
            array(
                "type" => "textfield",
                "class" => "",
                "heading" => esc_html__("Product Count", 'teba'),
                "param_name" => "number",
                "value" => "",
				"group" => esc_html__("Build Query", 'teba'),
				"description" => esc_html__('Please, enter number of post per page. Show all: -1.', 'teba')
            ),
            array (
				"type" => "dropdown",
				"heading" => esc_html__( 'Order by', 'teba' ),
				"param_name" => "orderby",
				"value" => array (
						"None"    => "none",
						"Date"    => "date",
						"Price"   => "price",
						"Random"  => "rand",
						"Selling" => "selling",
						"Rated"   => "rated",
				),
				"group" => esc_html__("Build Query", 'teba'),
				"description" => esc_html__( 'Order by ("none", "date", "price", "rand", "selling", "rated") in this element.', 'teba' )
			),
            array(
                "type" => "dropdown",
                "heading" => esc_html__('Order', 'teba'),
                "param_name" => "order",
                "value" => Array(
                    "None" => "none",
                    "ASC"  => "ASC",
                    "DESC" => "DESC"
                ),
				"group" => esc_html__("Build Query", 'teba'),
                "description" => esc_html__('Order ("None", "Asc", "Desc") in this element.', 'teba')
            ),
		)
	));