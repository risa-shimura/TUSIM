<?php
vc_map(array(
	"name" => esc_html__("Image Layers", 'teba'),
	"base" => "image_layers",
	"category" => esc_html__('Extra Elements', 'teba'),
	"icon" => "tb-icon-for-vc fa fa-clone",
	"params" => array(
	
	array(
            'type' => 'param_group',
            'heading' => esc_html__( 'Images Lists', 'teba' ),
            'param_name' => 'images_list',
            'description' => esc_html__( 'Enter values for list item', 'teba' ),
            'params' => array(
                array(
                    "type" => "attach_image",
                    "heading" =>esc_html__("List item",'teba'),
                    "param_name" => "images_list_item",
                ), 
				array(
						'type'				=> 'textfield',
						'param_name'		=> "offcet_x",
						'heading'			=> esc_html__('Horizontal offset', 'teba'),
						'description' => esc_html__('Add the layer offset in %, for example -100 or 100','teba'),
						'edit_field_class'	=> 'vc_column vc_col-sm-6',
					),
					array(
						'type'				=> 'textfield',
						'param_name'		=> 'offcet_y',
						'heading'			=> esc_html__('Vertical offset', 'teba'),
						'description'       => esc_html__('Add the layer offset in %, for example -100 or 100','teba'),
						'edit_field_class'	=> 'vc_column vc_col-sm-6',
					),
					array(
						'type'				=> 'dropdown',
						'param_name'		=> 'layer_animation',
						'heading'			=> esc_html__('Animation', 'teba'),
						'description'       => esc_html__('Choose the appear effect for the element','teba'),
						'value'				=> array(
							esc_html__('Fade In', 'teba')		=> 'fadeIn',
							esc_html__('Fade In Down', 'teba')  => 'fadeInDown',
							esc_html__('Fade In Left', 'teba')	=> 'fadeInLeft',
							esc_html__('Fade In Right', 'teba') => 'fadeInRight',
							esc_html__('Fade In Up', 'teba')	=> 'fadeInUp',
							esc_html__('Slide In Up', 'teba')	=> 'slideInUp',
							esc_html__('Slide In Down', 'teba')	=> 'slideInDown',
							esc_html__('Slide In Left', 'teba')	=> 'slideInLeft',
							esc_html__('Slide In Right', 'teba')=> 'slideInRight',
							esc_html__('Zoom In', 'teba')		=> 'zoomIn',
							esc_html__('Zoom In Left', 'teba')	=> 'zoomInLeft',
							esc_html__('Zoom In Right', 'teba')	=> 'zoomInRight',
							esc_html__('Zoom In Up', 'teba')	=> 'zoomInUp',
							esc_html__('Flip In X', 'teba')	=> 'flipInX',
							esc_html__('Flip In Y', 'teba')	=> 'flipInY',
						),
					),
					array(
						"type" => "textfield",
						"heading" => esc_html__("Extra Class", 'teba'),
						"param_name" => "el_class",
						"value" => "",
						"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
				),
            ),
        ),
		
	)
));