<?php
$url = TEBA_URI . '/assets/img/price/';
vc_map ( array (
		"name" => 'Package box',
		"base" => "Package_box",
        "icon" => "tb-icon-for-vc fa fa-money",
		"category" => esc_html__( 'Extra Elements', 'teba' ), 
		"params" => array (
			array(
				"type" => "dropdown",
				"class" => "",
				"heading" => esc_html__("Style", 'teba'),
				"param_name" => "style",
				"value" => array(
					"Style 1" => "style1",
					"Style 2" => "style2",
	                "Style 3" => "style3",
				),
	            "group"       => esc_html__("Style", 'teba'),
				"description" => esc_html__('Select style in this elment.', 'teba')
			),
			array(
					'type'	     => 'image_select',
					'heading'	 => '',
					'param_name' => 'style_image1',
					'value'      => $url . 'style1.jpg',
					'dependency' => Array('element' => "style", 'value' => array('style1')),
					"group"      => esc_html__("Style", 'teba'),
			),
			array(
					'type'	     => 'image_select',
					'heading'	 => '',
					'param_name' => 'style_image2',
					'value'      => $url . 'style2.jpg',
					'dependency' => Array('element' => "style", 'value' => array('style2')),
					"group"      => esc_html__("Style", 'teba'),
			),
			array(
					'type'	     => 'image_select',
					'heading'	 => '',
					'param_name' => 'style_image3',
					'value'      => $url . 'style3.jpg',
					'dependency' => Array('element' => "style", 'value' => array('style3')),
					"group"      => esc_html__("Style", 'teba'),
			),
			array(
				"type" => "attach_image",
				"class" => "",
				"heading" => esc_html__("Image", 'teba'),
				"param_name" => "image",
				"value" => "",
				"description" => esc_html__("Select image for demo item.", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Title", 'teba'),
				"param_name" => "title",
				"value" => "",
				"admin_label" => true,
				"description" => esc_html__("Please, enter Box Title in this element.", 'teba'),
	            'edit_field_class' => 'vc_col-sm-4'
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("price", 'teba'),
				"param_name" => "price",
				"value" => "",
				"description" => esc_html__("Please, enter price in this element.", 'teba'),
	            'edit_field_class' => 'vc_col-sm-4'
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("period", 'teba'),
				"param_name" => "period",
				"value" => "/ month",
				"description" => esc_html__("Please, enter period in this element.", 'teba'),
	           'edit_field_class' => 'vc_col-sm-4'
			),
			array(
				"type" => "textarea_html",
				"class" => "",
				"heading" => esc_html__("Content", 'teba'),
				"param_name" => "content_package",
				"value" => "",
				"description" => esc_html__("Please, enter features in this element.", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Button Label", 'teba'),
				"param_name" => "button_label",
				"value" => "Order Now",
				"description" => esc_html__("Please, enter button Label in this element.", 'teba'),
             	'edit_field_class' => 'vc_col-sm-6'
			),
			array(
				"type" => "vc_link",
				"class" => "",
				"heading" => esc_html__("Button url", 'teba'),
				"param_name" => "button_url",
				"value" => "",
				"description" => esc_html__("Please, enter button url in this element.", 'teba'),
	            'edit_field_class' => 'vc_col-sm-6'
			),
	        array(
				'type'       => 'dropdown',
				'param_name' => 'pricing_best',
				'heading'    => esc_html__( 'Pricing Best', 'teba' ),
				'value'      => array(
					esc_html__( 'No', 'teba' )  => '',
					esc_html__( 'Yes', 'teba' ) => 'depth active'
				),
				'edit_field_class' => 'vc_col-sm-6',
			),
	        array(
				"type" => "textfield",
				"heading" => esc_html__("Pricing Best Label", 'teba'),
				"param_name" => "pricing_best_label",
				"description" => esc_html__("Please, enter pricing best Label in this element.", 'teba'),
             	'edit_field_class' => 'vc_col-sm-6'
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'teba'),
				"param_name" => "el_class",
			),
      )
));