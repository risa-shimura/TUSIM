<?php
$url = TEBA_URI . '/assets/img/blog/';
vc_map ( array (
		"name" => 'Blog',
		"base" => "blog",
		"category" => esc_html__( 'Extra Elements', 'teba' ),
	    "icon" => "tb-icon-for-vc fa fa-qrcode",
		"params" => array (
			array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__("Template", 'teba'),
					"param_name" => "tpl",
					"admin_label" => true,
					"value" => array(
						"Image Middle"     => "grid",
						"Image Overlay"    => "grid2",
						"Image Background" => "grid3",
						"Grid Left"        => "grid4",
					),
					"description" => esc_html__('Select template of posts display in this element.', 'teba'),
			),
	       array(
				'type'	     => 'image_select',
				'heading'	 => '',
				'param_name' => 'style_image1',
	            'value'      => $url . 'style1.jpg',
				'dependency' => Array('element' => "tpl", 'value' => array('grid')),
			),
			array(
					'type'	     => 'image_select',
					'heading'	 => '',
					'param_name' => 'style_image2',
					'value'      => $url . 'style2.jpg',
					'dependency' => Array('element' => "tpl", 'value' => array('grid2')),
			),
			array(
					'type'	     => 'image_select',
					'heading'	 => '',
					'param_name' => 'style_image3',
					'value'      => $url . 'style3.jpg',
					'dependency' => Array('element' => "tpl", 'value' => array('grid3')),
			),
	        array(
					'type'	     => 'image_select',
					'heading'	 => '',
					'param_name' => 'style_image4',
					'value'      => $url . 'style4.jpg',
					'dependency' => Array('element' => "tpl", 'value' => array('grid4')),
			),
			array (
				"type" => "mo_taxonomy",
				"taxonomy" => "category",
				"heading" => esc_html__( "Categories", 'teba' ),
				"param_name" => "category",
				"group" => esc_html__("Build Query", 'teba'),
				"description" => esc_html__( "Note: By default, all your team will be displayed. <br>If you want to narrow output, select category(s) above. Only selected categories will be displayed.", 'teba' )
		   ),
	       array(
					"type" => "dropdown",
					"class" => "",
					"heading" => esc_html__("Columns", 'teba'),
					"param_name" => "columns",
					"value" => array(
						"2 Columns" => "2",
						"1 Columns" => "1",
						"3 Columns" => "3",
						"4 Columns" => "4"
					),
	                "group" => esc_html__("Build Query", 'teba'),
					"description" => esc_html__('Select columns display in this element.', 'teba'),
					'edit_field_class' => 'vc_col-sm-6',
			),
			array (
					"type" => "textfield",
					"heading" => esc_html__( 'Count', 'teba' ),
					"param_name" => "posts_per_page",
					'value' => '',
					"group" => esc_html__("Build Query", 'teba'),
					'edit_field_class' => 'vc_col-sm-6',
					"description" => esc_html__( 'The number of posts to display on each page. Set to "-1" for display all posts on the page.', 'teba' )
			),
	         array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Excerpt Length", 'teba'),
				"param_name" => "excerpt_lenght",
				"value" => "",
				'edit_field_class' => 'vc_col-sm-6',
	            "group" => esc_html__("Build Query", 'teba'),
				"description" => esc_html__("Please, Enter number excerpt lenght of post in this element. Default: 14", 'teba')
			),
			array(
				'type' => 'dropdown',
				'heading' => esc_html__('Type navigation', 'teba'),
				'description' => esc_html__('Select the type of navigation or disable it.', 'teba'),
				'param_name' => 'pagination',
				"group" => esc_html__("Build Query", 'teba'),
				'edit_field_class' => 'vc_col-sm-6',
				'value' => array(
					"None" => 'none',
					"Prev/Next buttons" => 'buttons',
					"Numeric" => 'numeric',
				),
			),
			array (
					"type" => "dropdown",
					"heading" => esc_html__( 'Order by', 'teba' ),
					"param_name" => "orderby",
					"value" => array (
							"None" => "none",
							"Title" => "title",
							"Date" => "date",
							"ID" => "ID"
					),
					'edit_field_class' => 'vc_col-sm-6',
					"group" => esc_html__("Build Query", 'teba'),
					"description" => esc_html__( 'Order by ("none", "title", "date", "ID").', 'teba' )
			),
			array (
					"type" => "dropdown",
					"heading" => esc_html__( 'Order', 'teba' ),
					"param_name" => "order",
					"value" => Array (
							"None" => "none",
							"ASC" => "ASC",
							"DESC" => "DESC"
					),
					'edit_field_class' => 'vc_col-sm-6',
					"group" => esc_html__("Build Query", 'teba'),
					"description" => esc_html__( 'Order ("None", "Asc", "Desc").', 'teba' )
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__( 'text', 'teba' ),
				"param_name" => "link_text",
				"value" => "",
				'edit_field_class' => 'vc_col-sm-6',
				"group" => esc_html__("Build Query", 'teba'),
				"description" => esc_html__("Please, enter link text in this element. Default: Read More", 'teba')
			),
			array(
				"type" => "textfield",
				"class" => "",
				"heading" => esc_html__("Extra Class", 'teba'),
				"param_name" => "el_class",
				"value" => "",
				'edit_field_class' => 'vc_col-sm-6',
				"group" => esc_html__("Build Query", 'teba'),
				"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
			),
		)
));