<?php
vc_map(array(
	"name" => esc_html__("Timeline", 'teba'),
	"base" => "timeline",
	"category" => esc_html__('Extra Elements', 'teba'),
    "icon" => "tb-icon-for-vc fa fa-bars",
	"params" => array(
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Number Step", 'teba'),
			"param_name" => "number_step",
			"value" => "",
			"description" => esc_html__("Please, enter number step in this element.", 'teba')
		),
	     /* Start Icon */
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon library', 'teba' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'teba' ) => 'fontawesome',
                esc_html__( 'Linecons', 'teba' )     => 'linecons',
	            esc_html__( 'Ionicons', 'teba' )     => 'ionicons',
				esc_html__( 'P7 Stroke', 'teba' )    => 'pe7stroke',
	            esc_html__( 'ET-line', 'teba' )      => 'etline',
            ),
            'param_name'  => 'icon',
            'description' => esc_html__( 'Select icon library.', 'teba' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_fontawesome',
	        'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'fontawesome',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	
	   array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_linecons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'linecons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'linecons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_ionicons',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'ionicons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'ionicons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	   array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_pe7stroke',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'pe7stroke',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'pe7stroke',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_etline',
            'value' => '',
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'etline',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'etline',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
        /* End Icon */
		array(
			"type" => "textfield",
			"holder" => "div",
			"class" => "",
			"heading" => esc_html__("Title", 'teba'),
			"param_name" => "title",
			"value" => "",
			"description" => esc_html__("Please, enter title in this element.", 'teba')
		),
		array(
			"type" => "textarea_html",
			"class" => "",
			"heading" => esc_html__("Description", 'teba'),
			"param_name" => "content",
			"value" => "",
			"description" => esc_html__("Please, enter description in this element.", 'teba')
		),
	   array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Animation CSS', 'teba' ),
            'value' => array(
	            esc_html__( 'none', 'teba' )          => 'none',
                esc_html__( 'bounceIn', 'teba' )      => 'wow bounceIn',
                esc_html__( 'bounceInDown', 'teba' )  => 'wow bounceInDown',
                esc_html__( 'bounceInLeft', 'teba' )  => 'wow bounceInLeft',
			    esc_html__( 'bounceInRight', 'teba' ) => 'wow bounceInRight',
			    esc_html__( 'bounceInUp', 'teba' )    => 'wow bounceInUp',
			    esc_html__( 'fadeIn', 'teba' )        => 'wow fadeIn',
			    esc_html__( 'fadeInDown', 'teba' )    => 'wow fadeInDown',
			    esc_html__( 'fadeInDownBig', 'teba' ) => 'wow fadeInDownBig',
			    esc_html__( 'fadeInLeft', 'teba' )    => 'wow fadeInLeft',
			    esc_html__( 'fadeInLeftBig', 'teba' ) => 'wow fadeInLeftBig',
			    esc_html__( 'fadeInRight', 'teba' )   => 'wow fadeInRight',
			    esc_html__( 'fadeInRightBig', 'teba' )=> 'wow fadeInRightBig',
			    esc_html__( 'fadeInUp', 'teba' )      => 'wow fadeInUp',
			    esc_html__( 'fadeInUpBig', 'teba' )   => 'wow fadeInUpBig',
			    esc_html__( 'flipInX', 'teba' )       => 'wow flipInX',
			    esc_html__( 'flipInY', 'teba' )       => 'wow flipInY',
                esc_html__( 'slideInUp', 'teba' )     => 'wow slideInUp',
                esc_html__( 'slideInDown', 'teba' )   => 'wow slideInDown',
			    esc_html__( 'slideInLeft', 'teba' )   => 'wow slideInLeft',
			    esc_html__( 'slideInRight', 'teba' )  => 'wow slideInRight',
			    esc_html__( 'zoomIn', 'teba' )        => 'wow zoomIn',
			    esc_html__( 'zoomInDown', 'teba' )    => 'wow zoomInDown',
			    esc_html__( 'zoomInLeft', 'teba' )    => 'wow zoomInLeft',
			    esc_html__( 'zoomInRight', 'teba' )   => 'wow zoomInRight',
			    esc_html__( 'zoomInUp', 'teba' )      => 'wow zoomInUp',
            ),
            'param_name' => 'animation_css',
            'description' => esc_html__( 'Select animation type.', 'teba' ),
        ),
	    array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Animation Delay', 'teba' ),
            'value' => array(
                esc_html__( '0.1s', 'teba' ) => '0.1s',
                esc_html__( '0.2s', 'teba' ) => '0.2s',
                esc_html__( '0.3s', 'teba' ) => '0.3s',
	            esc_html__( '0.4s', 'teba' ) => '0.4s',
                esc_html__( '0.5s', 'teba' ) => '0.5s',
                esc_html__( '0.6s', 'teba' ) => '0.6s',
                esc_html__( '0.7s', 'teba' ) => '0.7s',
	            esc_html__( '0.8s', 'teba' ) => '0.8s',
                esc_html__( '0.9s', 'teba' ) => '0.9s',
            ),
            'param_name' => 'animation_delay',
		    'description' => esc_html__( 'Select animation delay.', 'teba' ),
        ),
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));