<?php
$url = TEBA_URI . 'assets/img/button/';
vc_map(array(
	"name" => esc_html__("button", 'teba'),
	"base" => "button",
	"category" => esc_html__('Extra Elements', 'teba'),
    "icon" => "tb-icon-for-vc fa fa-minus",
	"params" => array(
		array(
			'type'       => 'select_preview',
			'param_name' => 'style',
			'heading'    => esc_html__('Style', 'teba'),
			'value'      => array(
				array(
					'value' => 'btn-solid',
					'label' => esc_html__('Solid', 'teba'),
					'image' => $url . 'solid.jpg'
				),
				array(
					'label' => esc_html__('Bordered', 'teba'),
					'value' => 'btn-border',
	                'image' => $url . 'bordered.jpg'
				),
				array(
					'label' => esc_html__('Text only', 'teba'),
					'value' => 'btn-txt',
					'image' => $url . 'text.jpg'
				),
			),
			'save_always' => true,
		),
	    array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__( 'text', 'teba' ),
			"param_name" => "text",
			"value" => "",
	        "admin_label" => true,
			"description" => esc_html__("Please, enter button text in this element.", 'teba')
		),
		array(
			"type" => "vc_link",
			"class" => "",
			"heading" => esc_html__( 'Link', 'teba' ),
			"param_name" => "link",
			"value" => "",
			"description" => esc_html__("Please, enter button link in this element.", 'teba')
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("style", 'teba'),
			"param_name" => "hr_style",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
	            "Solid"          => "linear",
	            "Roll"            => "roll",
	            "shine"           => "hover_shine",
				"Slide"           => "slide",
				"Icon"            => "icon",
	            "lineMove Bottom" => "line-move-bottom",
	            "lineMove Left"   => "line-move-Left",
			),
	         "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-solid', 'btn-border')
		    ),
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("style", 'teba'),
			"param_name" => "btn_txt_style",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
	            "circle"      => "btn-txt-circle",
	            "arrow"       => "btn-txt-arrow",
	            "underlined"  => "btn-txt-underlined",
			),
	         "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-txt')
		    ),
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("background color", 'teba'),
			"param_name" => "bg_color",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
				"primary"   => "bg_primary",
				"light"     => "bg_light",
	            "grey"      => "bg_grey",
				"dark"      => "bg_dark",
			),
	        "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-solid')
		    ),
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("background color (hover)", 'teba'),
			"param_name" => "hr_bg_color",
			"group" => esc_html__("Style", 'teba'),
 			"value" => array(
				"primary"    => "bg_hr_primary",
				"light"      => "bg_hr_light",
            	"grey"       => "bg_hr_grey",
				"dark"       => "bg_hr_dark",
			),
	       "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-solid' , 'btn-border')
		    ),
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("font color", 'teba'),
			"param_name" => "color",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
	            "light"     => "light",
				"primary"   => "primary",
				"dark"      => "dark"
			),
	       'edit_field_class' => 'vc_col-sm-6 vc_column-with-padding',
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("font color (hover)", 'teba'),
			"param_name" => "hr_color",
			"group" => esc_html__("Style", 'teba'),
 			"value" => array(
	            "light"      => "hr_light",
				"primary"    => "hr_primary",
				"dark"       => "hr_dark"
			),
	        'edit_field_class' => 'vc_col-sm-6 vc_column-with-padding',
		),
	    array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("border color", 'teba'),
			"param_name" => "outline_color",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
		        "grey"      => "outline_grey",
				"primary"   => "outline_primary",
				"light"     => "outline_light",
				"dark"      => "outline_dark",
			),
	        "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-border')
		    ),
	       'edit_field_class' => 'vc_col-sm-6 vc_column-with-padding',
		),
	   array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("border color (hover)", 'teba'),
			"param_name" => "outline_hr_color",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
		        "grey"      => "outline_hr_grey",
				"primary"   => "outline_hr_primary",
				"light"     => "outline_hr_light",
				"dark"      => "outline_hr_dark",
			),
	        "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-border')
		    ),
	        'edit_field_class' => 'vc_col-sm-6 vc_column-with-padding',
		),
	    array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("style", 'teba'),
			"param_name" => "radius",
	       	"group" => esc_html__("Style", 'teba'),
			"value" => array(
				"radius 5"  => "radius5",
				"radius 0"  => "radius0",
	            "radius 50" => "radius50",
			),
	       'edit_field_class' => 'vc_col-sm-6 vc_column-with-padding',
	        "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-solid' , 'btn-border')
		    ),
		),
		array(
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("size", 'teba'),
			"param_name" => "size",
			"group" => esc_html__("Style", 'teba'),
			"value" => array(
			    "medium" => "medium",
				"small"  => "small",
				"large"  => "large",
			),
	       'edit_field_class' => 'vc_col-sm-6 vc_column-with-padding',
	       "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-solid' , 'btn-border')
		    ),
		),
		array(
		    "type" => "dropdown",
			"heading" => esc_html__("Button Position", 'teba'),
			"param_name" => "position",
			"value" => array(
				"center" => "text-center",
				"right"  => "text-right",
				"left"   => "text-left",
			),
		),
	    /* Start Icon */
	    array(
		    "type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("Show or hide icon", 'teba'),
			"param_name" => "show_icon",
		    "group" => esc_html__("Icon", 'teba'),
			"value" => array(
				"no"  => "no_icon",
				"yes" => "had_icon",
			),
	       "dependency" => array(
	           "element"=>"style",
			   "value"=> array('btn-solid')
		    ),
		),
        array(
            'type' => 'dropdown',
            'heading' => esc_html__( 'Icon library', 'teba' ),
            'value' => array(
                esc_html__( 'Font Awesome', 'teba' ) => 'fontawesome',
                esc_html__( 'Linecons', 'teba' )     => 'linecons',
	            esc_html__( 'Ionicons', 'teba' )     => 'ionicons',
				esc_html__( 'P7 Stroke', 'teba' )    => 'pe7stroke',
	            esc_html__( 'ET-line', 'teba' )      => 'etline',
            ),
	        "group" => esc_html__("Icon", 'teba'),
            'param_name' => 'icon',
            'description' => esc_html__( 'Select icon library.', 'teba' ),
			'dependency' => Array('element' => "show_icon", 'value' => array('had_icon'))
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_fontawesome',
            'value' => '',
		    "group" => esc_html__("Icon", 'teba'),
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'fontawesome',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'fontawesome',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	   array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_linecons',
            'value' => '',
		    "group" => esc_html__("Icon", 'teba'),
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'linecons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'linecons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_ionicons',
            'value' => '',
		    "group" => esc_html__("Icon", 'teba'),
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'ionicons',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'ionicons',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
	   array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_pe7stroke',
            'value' => '',
		    "group" => esc_html__("Icon", 'teba'),
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'pe7stroke',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'pe7stroke',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
        array(
            'type' => 'iconpicker',
            'heading' => esc_html__( 'Icon Item', 'teba' ),
            'param_name' => 'icon_etline',
            'value' => '',
		    "group" => esc_html__("Icon", 'teba'),
            'settings' => array(
                'emptyIcon' => true, // default true, display an "EMPTY" icon?
                'type' => 'etline',
                'iconsPerPage' => 200, // default 100, how many icons per/page to display
            ),
            'dependency' => array(
                'element' => 'icon',
                'value' => 'etline',
            ),
            'description' => esc_html__( 'Select icon from library.', 'teba' ),
        ),
        /* End Icon */
	    
		array(
			"type" => "textfield",
			"class" => "",
			"heading" => esc_html__("Extra Class", 'teba'),
			"param_name" => "el_class",
			"value" => "",
			"description" => esc_html__( "If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.", 'teba' )
		),
	)
));