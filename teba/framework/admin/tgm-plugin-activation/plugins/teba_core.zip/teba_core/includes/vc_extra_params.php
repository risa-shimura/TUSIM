<?php
vc_add_param ( "vc_row", array (
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__("row style", 'teba'),
		"param_name" => "row_separator",
		"group"         => esc_html__("Custom Options", 'teba'),
		"description" => esc_html__("Select shap style in this row.",'teba'),
		"value" => array(
			esc_html__("None Select", 'teba')    => "none",
			esc_html__("triangle", 'teba')       => "lg_triangle",
			esc_html__("round", 'teba')          => "round",
			esc_html__("curve", 'teba')          => "curve",
			esc_html__("angled left", 'teba')    => "angled_left",
			esc_html__("angled right", 'teba')   => "angled_right",
			esc_html__("wave", 'teba')           => "wave",
			esc_html__("waves", 'teba')          => "waves",
		 )
) );
vc_add_param ( "vc_row", array (
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__("position separator", 'teba'),
		"param_name" => "position_separator",
		"group"         => esc_html__("Custom Options", 'teba'),
		"description" => esc_html__("Select shap position in this row.",'teba'),
		"value" => array(
			esc_html__("bottom", 'teba') => "svg_bottom",
			esc_html__("top", 'teba')    => "svg_top",
			esc_html__("top AND bottom", 'teba')  => "svg_top_bottom")
) );
vc_add_param ( "vc_row", array (
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__("color separator", 'teba'),
		"param_name" => "color_separator",
		"group"         => esc_html__("Custom Options", 'teba'),
		"description" => esc_html__("Select shap color style in this row.",'teba'),
		"value" => array(
			esc_html__("None", 'teba')      => "svg_none",
			esc_html__("White", 'teba')     => "svg_white",
			esc_html__("Grey", 'teba')      => "svg_grey",
			esc_html__("Dark", 'teba')      => "svg_dark",
	        esc_html__("Black", 'teba')     => "svg_black",
			esc_html__("Primary", 'teba')   => "svg_primary")
) );
vc_add_param ( "vc_row", array (
		"type" => "dropdown",
		"class" => "",
		"heading" => esc_html__("bottom color separator", 'teba'),
		"param_name" => "bottom_color_separator",
		"group"         => esc_html__("Custom Options", 'teba'),
		"description" => esc_html__("Select bottom shap color style in this row.",'teba'),
		'dependency'  => array(
		   "element"=>"position_separator",
		   "value"=>  "svg_top_bottom",
		),
		"value" => array(
			esc_html__("None", 'teba')      => "svg_bottom_none",
			esc_html__("White", 'teba')     => "svg_bottom_white",
			esc_html__("Grey", 'teba')      => "svg_bottom_grey",
			esc_html__("Dark", 'teba')      => "svg_bottom_dark",
			esc_html__("Primary", 'teba')   => "svg_bottom_primary")
) );
vc_add_param ( "vc_row", array (
			"type" => "dropdown",
			"class" => "",
			"heading" => esc_html__("canvas", 'teba'),
			"param_name" => "canvas",
			"group"       => esc_html__("Custom Options", 'teba'),
			"description" => esc_html__("Select the particles in this element.",'teba'),
			"value" => array(
				esc_html__("None Select", 'teba') => "none",
				esc_html__("particles style 1", 'teba') => "particles1",
				esc_html__("particles style 2", 'teba') => "particles2")
) );
	vc_add_param ( "vc_row", array (
		"type"       => "dropdown",
		"class"      => "",
		"heading"    => esc_html__("Background color", 'teba'),
		"param_name" => "content_bg_color",
		"group"      => esc_html__("Design Options", 'teba'),
		"description" 	=> esc_html__( "Select background color in this row.", 'teba' ),
		"value"      => array(
			esc_html__("light", 'teba')     => "bg-light",
			esc_html__("Grey", 'teba')      => "bg-grey",
			esc_html__("Dark grey", 'teba') => "bg-dark-grey",
			esc_html__("Dark", 'teba')      => "bg-dark",
			esc_html__("Primary", 'teba')   => "bg-color-main")
) );
vc_add_param ( "vc_row", array (
		"type"       => "dropdown",
		"class"      => "",
		"heading"    => esc_html__("content color", 'teba'),
		"param_name" => "content_color",
		"group"      => esc_html__("Design Options", 'teba'),
		"description" 	=> esc_html__( "Select content text color in this row.", 'teba' ),
		"value"      => array(
			esc_html__("Dark Text", 'teba')  => "dark_txt",
			esc_html__("White Text", 'teba') => "white_txt")
) );
vc_add_param ( "vc_row", array (
		"type" 			=> "colorpicker",
		"class" 		=> "",
		"heading" 		=> esc_html__( "Gradient Overlay 'primary color'", 'teba' ),
		"param_name" 	=> "mo_bg_overlay",
		"value" 		=> "",
		"group"         => esc_html__("Design Options", 'teba'),
		"description" 	=> esc_html__( "Select color Gradient background overlay ( primary color ) in this row.", 'teba' )
) );
vc_add_param ( "vc_row", array (
		"type" 			=> "colorpicker",
		"class" 		=> "",
		"heading" 		=> esc_html__( "Gradient Overlay 'second color'", 'teba' ),
		"param_name" 	=> "mo_bg_second_overlay",
		"value" 		=> "",
		"group"         => esc_html__("Design Options", 'teba'),
		"description" 	=> esc_html__( "Select color Gradient background overlay ( second color ) in this row.", 'teba' )
) );
vc_add_param ( "vc_row", array (
		"type" 			=> "checkbox",
		"class" 		=> "",
		"heading" 		=> esc_html__( "Background Fixed", 'teba' ),
		"param_name" 	=> "mo_bg_fixed",
		"value" 		=> "",
		"group"         => esc_html__("Design Options", 'teba'),
		"description" 	=> esc_html__( "Enable background fixed in this row.", 'teba' )
) );
vc_add_param ( "vc_custom_heading", array (
		"type" 			=> "textarea",
		"class" 		=> "",
		"heading" 		=> esc_html__( "Custom CSS", 'teba' ),
		"param_name" 	=> "custom_css",
		"value" 		=> "",
		"description" 	=> esc_html__( "Enter style in this custom heading. EX: line-height: 24px; letter-spacing: 0.04em; ...", 'teba' )
) );


// New Params for Row
function mo_row_extras() {
	$custom_animation_params = array(
		array(
			'type'             => 'checkbox',
			'param_name'       => 'content_animation',
			'value'            => array( esc_html__( 'Yes', 'teba' ) => 'yes' ),
			'heading'          => esc_html__( 'Animate Columns?', 'teba' ),
			'description'      => esc_html__( 'Will enable animation for columns, it will be animated when it "enters" the browsers viewport (Note: works only in modern browsers).', 'teba' ),
		    'group' => esc_html__( 'Animation', 'teba' ),
		),
		//Custom Animation Options
		array(
			'type'        => 'textfield',
			'param_name'  => 'mo_duration',
			'heading'     => esc_html__( 'Duration', 'teba' ),
			'description' => esc_html__( 'Add duration of the animation in milliseconds EX:1200', 'teba' ),
			'dependency'  => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4 vc_column-with-padding',
			'group' => esc_html__( 'Animation', 'teba' ),
		),
		array(
			'type' => 'textfield',
			'param_name' => 'mo_start_delay',
			'heading' => esc_html__( 'Start Delay', 'teba' ),
			'description' => esc_html__( 'Add start delay of the animation in milliseconds EX:100', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
			'group' => esc_html__( 'Animation', 'teba' ),
		),
		array(
			'type' => 'textfield',
			'param_name' => 'mo_delay',
			'heading' => esc_html__( 'Delay', 'teba' ),
			'description' => esc_html__( 'Add delay of the animation between of the animated elements in milliseconds', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
			'group' => esc_html__( 'Animation', 'teba' ),
		),
		array(
			'type' => 'dropdown',
			'param_name' => 'mo_easing',
			'heading' => esc_html__( 'Easing', 'teba' ),
			'description' => esc_html__( 'Select an easing type', 'teba' ),
			'value' => array(
				'linear',
				'easeInQuad',
				'easeInCubic',
				'easeInQuart',
				'easeInQuint',
				'easeInSine',
				'easeInExpo',
				'easeInCirc',
				'easeInBack',
				'easeOutQuad',
				'easeOutCubic',
				'easeOutQuart',
				'easeOutQuint',
				'easeOutSine',
				'easeOutExpo',
				'easeOutCirc',
				'easeOutBack',
				'easeInOutQuad',
				'easeInOutCubic',
				'easeInOutQuart',
				'easeInOutQuint',
				'easeInOutSine',
				'easeInOutExpo',
				'easeInOutCirc',
				'easeInOutBack',
			),
			'std' => 'easeOutQuint',
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
			'group' => esc_html__( 'Animation', 'teba' ),
		),
		array(
			'type'        => 'dropdown',
			'param_name'  => 'mo_direction',
			'heading'     => esc_html__( 'Direction', 'teba' ),
			'description' => esc_html__( 'Select animations direction', 'teba' ),
			'value' => array(
				esc_html__( 'Forward', 'teba' )  => 'forward',
				esc_html__( 'Backward', 'teba' )  => 'backward',
			),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
			'group' => esc_html__( 'Animation', 'teba' ),
		),
		array(
			'type'        => 'subheading',
			'param_name'  => 'mo_init_values',
			'heading'     => esc_html__( 'Animate From', 'teba' ),
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_translate_x',
			'heading'     => esc_html__( 'Translate X', 'teba' ),
			'description' => esc_html__( 'Select translate on X axe', 'teba' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		    'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_translate_y',
			'heading'     => esc_html__( 'Translate Y', 'teba' ),
			'description' => esc_html__( 'Select translate on Y axe', 'teba' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_translate_z',
			'heading'     => esc_html__( 'Translate Z', 'teba' ),
			'description' => esc_html__( 'Select translate on Z axe', 'teba' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		   'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_scale_x',
			'heading'     => esc_html__( 'Scale X', 'teba' ),
			'description' => esc_html__( 'Select Scale X', 'teba' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_scale_y',
			'heading'     => esc_html__( 'Scale Y', 'teba' ),
			'description' => esc_html__( 'Select Scale Y', 'teba' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_scale_z',
			'heading'     => esc_html__( 'Scale Z', 'teba' ),
			'description' => esc_html__( 'Select Scale Z', 'teba' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_rotate_x',
			'heading'     => esc_html__( 'Rotate X', 'teba' ),
			'description' => esc_html__( 'Select rotate degree on X axe', 'teba' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		    'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_rotate_y',
			'heading'     => esc_html__( 'Rotate Y', 'teba' ),
			'description' => esc_html__( 'Select rotate degree on Y axe', 'teba' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
	    	'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_rotate_z',
			'heading'     => esc_html__( 'Rotate Z', 'teba' ),
			'description' => esc_html__( 'Select rotate degree on Z axe', 'teba' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency'  => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
	    	'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_init_opacity',
			'heading'     => esc_html__( 'Opacity', 'teba' ),
			'description' => esc_html__( 'Set opacity', 'teba' ),
			'min'         => 0,
			'max'         => 1,
			'step'        => 0.1,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency'  => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		   'edit_field_class' => 'vc_col-sm-11',
		),
		//Animation Values
		array(
			'type'        => 'subheading',
			'param_name'  => 'mo_animations_values',
			'heading'     => esc_html__( 'Animate To', 'teba' ),
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		),			
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_translate_x',
			'heading'     => esc_html__( 'Translate X', 'teba' ),
			'description' => esc_html__( 'Select translate on X axe', 'teba' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
	    	'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_translate_y',
			'heading'     => esc_html__( 'Translate Y', 'teba' ),
			'description' => esc_html__( 'Select translate on Y axe', 'teba' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
	    	'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_translate_z',
			'heading'     => esc_html__( 'Translate Z', 'teba' ),
			'description' => esc_html__( 'Select translate on Z axe', 'teba' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		   'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_scale_x',
			'heading'     => esc_html__( 'Scale X', 'teba' ),
			'description' => esc_html__( 'Select Scale X', 'teba' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_scale_y',
			'heading'     => esc_html__( 'Scale Y', 'teba' ),
			'description' => esc_html__( 'Select Scale Y', 'teba' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_scale_z',
			'heading'     => esc_html__( 'Scale Z', 'teba' ),
			'description' => esc_html__( 'Select Scale Z', 'teba' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_rotate_x',
			'heading'     => esc_html__( 'Rotate X', 'teba' ),
			'description' => esc_html__( 'Select rotate degree on X axe', 'teba' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		   'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_rotate_y',
			'heading'     => esc_html__( 'Rotate Y', 'teba' ),
			'description' => esc_html__( 'Select rotate degree on Y axe', 'teba' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		    'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_rotate_z',
			'heading'     => esc_html__( 'Rotate Z', 'teba' ),
			'description' => esc_html__( 'Select rotate degree on Z axe', 'teba' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency' => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		    'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'mo_an_opacity',
			'heading'     => esc_html__( 'Opacity', 'teba' ),
			'description' => esc_html__( 'Set opacity', 'teba' ),
			'min'         => 0,
			'max'         => 1,
			'step'        => 0.1,
			'std'         => 1,
			'group' => esc_html__( 'Animation', 'teba' ),
			'dependency'  => array(
				'element' => 'content_animation',
				'value'   => 'yes',
			),
		    'edit_field_class' => 'vc_col-sm-11'
		),
	);
	vc_add_params( 'vc_row', $custom_animation_params );
    vc_add_params( 'vc_row_inner', $custom_animation_params );	
}
add_action( 'vc_after_init', 'mo_row_extras' );

// New Params for Row
function mo_column_extras() {
	$paralax_params = array(
		//Paralax settings for vc_column and vc_column_inner
		array(
			'type'        => 'checkbox',
			'param_name'  => 'parallax_animation',
			'heading'     => esc_html__( 'Animate Content Parallax?', 'ave-core' ),
			'description' => esc_html__( 'Add parallax for column.', 'ave-core' ),
			'value'       => array( esc_html__( 'Yes', 'ave-core' )  => 'yes' ),
		    'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
		),
		array(
			'type'        => 'subheading',
			'param_name'  => 'prlx_from',
			'heading'     => esc_html__( 'Parallax "From" Options', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'translate_from_x',
			'heading'     => esc_html__( 'Translate X', 'ave-core' ),
			'description' => esc_html__( 'Select translate on X axe', 'ave-core' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'translate_from_y',
			'heading'     => esc_html__( 'Translate Y', 'ave-core' ),
			'description' => esc_html__( 'Select translate on Y axe', 'ave-core' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'translate_from_z',
			'heading'     => esc_html__( 'Translate Z', 'ave-core' ),
			'description' => esc_html__( 'Select translate on Z axe', 'ave-core' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
           'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'scale_from_x',
			'heading'     => esc_html__( 'Scale X', 'ave-core' ),
			'description' => esc_html__( 'Select Scale X', 'ave-core' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'scale_from_y',
			'heading'     => esc_html__( 'Scale Y', 'ave-core' ),
			'description' => esc_html__( 'Select Scale Y', 'ave-core' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'scale_from_z',
			'heading'     => esc_html__( 'Scale Z', 'ave-core' ),
			'description' => esc_html__( 'Select Scale Z', 'ave-core' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'rotate_from_x',
			'heading'     => esc_html__( 'Rotate X', 'ave-core' ),
			'description' => esc_html__( 'Select rotate degree on X axe', 'ave-core' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'rotate_from_y',
			'heading'     => esc_html__( 'Rotate Y', 'ave-core' ),
			'description' => esc_html__( 'Select rotate degree on Y axe', 'ave-core' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'rotate_from_z',
			'heading'     => esc_html__( 'Rotate Z', 'ave-core' ),
			'description' => esc_html__( 'Select rotate degree on Z axe', 'ave-core' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'from_opacity',
			'heading'     => esc_html__( 'Opacity', 'ave-core' ),
			'description' => esc_html__( 'Set opacity', 'ave-core' ),
			'min'         => 0,
			'max'         => 1,
			'step'        => 0.1,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),

		),
		array(
			'type'        => 'subheading',
			'param_name'  => 'prlx_to',
			'heading'     => esc_html__( 'Parallax "To" Options', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'translate_to_x',
			'heading'     => esc_html__( 'Translate X', 'ave-core' ),
			'description' => esc_html__( 'Select translate on X axe', 'ave-core' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'translate_to_y',
			'heading'     => esc_html__( 'Translate Y', 'ave-core' ),
			'description' => esc_html__( 'Select translate on Y axe', 'ave-core' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
           'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'translate_to_z',
			'heading'     => esc_html__( 'Translate Z', 'ave-core' ),
			'description' => esc_html__( 'Select translate on Z axe', 'ave-core' ),
			'min'         => -500,
			'max'         => 500,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'scale_to_x',
			'heading'     => esc_html__( 'Scale X', 'ave-core' ),
			'description' => esc_html__( 'Select Scale X', 'ave-core' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',

		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'scale_to_y',
			'heading'     => esc_html__( 'Scale Y', 'ave-core' ),
			'description' => esc_html__( 'Select Scale Y', 'ave-core' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'scale_to_z',
			'heading'     => esc_html__( 'Scale Z', 'ave-core' ),
			'description' => esc_html__( 'Select Scale Z', 'ave-core' ),
			'min'         => 0,
			'max'         => 10,
			'step'        => 0.25,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'rotate_to_x',
			'heading'     => esc_html__( 'Rotate X', 'ave-core' ),
			'description' => esc_html__( 'Select rotate degree on X axe', 'ave-core' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'rotate_to_y',
			'heading'     => esc_html__( 'Rotate Y', 'ave-core' ),
			'description' => esc_html__( 'Select rotate degree on Y axe', 'ave-core' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'rotate_to_z',
			'heading'     => esc_html__( 'Rotate Z', 'ave-core' ),
			'description' => esc_html__( 'Select rotate degree on Z axe', 'ave-core' ),
			'min'         => -360,
			'max'         => 360,
			'step'        => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
            'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'mo_slider',
			'param_name'  => 'to_opacity',
			'heading'     => esc_html__( 'Opacity', 'ave-core' ),
			'description' => esc_html__( 'Set opacity', 'ave-core' ),
			'min'         => 0,
			'max'         => 1,
			'step'        => 0.1,
			'std'         => 1,
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
		),
		array(
			'type'        => 'subheading',
			'param_name'  => 'prlx_common',
			'heading'     => esc_html__( 'Parallax Settings', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
		),
		array(
			'type'        => 'dropdown',
			'param_name'  => 'to_easy',
			'heading'     => esc_html__( 'Animation Easing', 'ave-core' ),
			'description' => '',
			'value'       => array(
				'linear',
				'easeInQuad',
				'easeInCubic',
				'easeInQuart',
				'easeInQuint',
				'easeInSine',
				'easeInExpo',
				'easeInCirc',
				'easeInBack',
				'easeOutQuad',
				'easeOutCubic',
				'easeOutQuart',
				'easeOutQuint',
				'easeOutSine',
				'easeOutExpo',
				'easeOutCirc',
				'easeOutBack',
				'easeInOutQuad',
				'easeInOutCubic',
				'easeInOutQuart',
				'easeInOutQuint',
				'easeInOutSine',
				'easeInOutExpo',
				'easeInOutCirc',
				'easeInOutBack',
			),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
		    'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'to_delay',
			'heading'     => esc_html__( 'Delay', 'ave-core' ),
			'description' => esc_html__( 'Add delay time in seconds', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
		    'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'parallax_time',
			'heading'     => esc_html__( 'Parallax Time', 'ave-core' ),
			'description' => esc_html__( 'Duration of the animation in sec', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'parallax_offset',
			'heading'     => esc_html__( 'Parallax Offset', 'ave-core' ),
			'description' => esc_html__( 'Offset number', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			 'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'parallax_trigger',
			'heading'    => esc_html__( 'Parallax Trigger', 'ave-core' ),
			'value' => array(
				esc_html__( 'On Enter', 'ave-core' )  => 'onEnter',
				esc_html__( 'On Leave', 'ave-core' ) => 'onLeave',
				esc_html__( 'On Center', 'ave-core' ) => 'onCenter',
				esc_html__( 'Number Value', 'ave-core' ) => 'number',
			),
			'std'        => 'onEnter',
			'group'      => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency' => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			 'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'parallax_trigger_number',
			'heading'     => esc_html__( 'Parallax Trigger Number', 'ave-core' ),
			'description' => esc_html__( 'Input trigger number value from 0 to 1', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_trigger',
				'value'   => 'number'
			),
			 'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'textfield',
			'param_name'  => 'parallax_duration',
			'heading'     => esc_html__( 'Parallax Duration', 'ave-core' ),
			'description' => esc_html__( 'define how much the animation last during the scroll. could be defined in px (150) or percent(100%)', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'dependency'  => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			 'edit_field_class' => 'vc_col-sm-4',
		),
		array(
			'type'        => 'dropdown',
			'param_name'  => 'enable_reverse',
			'heading'     => esc_html__( 'Enable Reverse', 'ave-core' ),
			'description' => esc_html__( 'Will enable animation each time the element will come in viewport', 'ave-core' ),
			'group'       => esc_html__( 'Parallax Options', 'ave-core' ),
			'value'       => array(
				esc_html__( 'No', 'ave-core' ) => 'no',
				esc_html__( 'Yes', 'ave-core' ) => 'yes',
			),
			'std' => 'yes',
			'dependency' => array(
				'element' => 'parallax_animation',
				'value'   => 'yes'
			),
			 'edit_field_class' => 'vc_col-sm-4',
		),
	);	
	vc_add_params( 'vc_column', $paralax_params );
    vc_add_params( 'vc_column_inner', $paralax_params );	
}
add_action( 'vc_after_init', 'mo_column_extras' );

// Shortcode 
// source : https://wpbakery.atlassian.net/wiki/pages/viewpage.action?pageId=524362
if(!function_exists('carousel_content')){
    function carousel_content( $atts, $content = null ) {
       return '<div class="owl-carousel content-carousel content-slider">'.do_shortcode($content).'</div>';
    }
    add_shortcode('carousel_content', 'carousel_content');
}

if(!function_exists('single_carousel_content')) {
	function single_carousel_content( $atts, $content =  null) {
		extract(shortcode_atts(array(
			'title' => 'Flexible & Customizable',
			'description' => '',
			'url' => '',
			'img' => ''
		), $atts));
        
        $url = ($url=='||') ? '' : $url;
		$url = ps_build_link( $url );
		$a_link = $url['url'];
		$a_title = ($url['title'] == '') ? '' : 'title="'.$url['title'].'"';
		$a_target = ($url['target'] == '') ? '' : 'target="'.$url['target'].'"';
        $button = $a_link ? '<a class="btn btn-md btn-black" href="'.$a_link. '" '.$a_title.' '.$a_target.'>'.$url['title'].'</a>' : '';

        $image = wp_get_attachment_image_src( $img, 'full');
		$image_src = $image['0'];
        
        
        $output = '<div class="item">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6 mb-sm-30">
                                <img src="'.$image_src.'" alt="" />
                            </div>
                            <div class="col-md-5 col-md-offset-1">
                                <h3>'.$title.'</h3>
                                <div class="spacer-15"></div>
                                '.$description.'
                                <div class="spacer-15"></div>
                                '.$button.'
                            </div>
                        </div>
                    </div>
                </div>'; 
        
        return $output;
	}
	add_shortcode('single_carousel_content', 'single_carousel_content');		
}